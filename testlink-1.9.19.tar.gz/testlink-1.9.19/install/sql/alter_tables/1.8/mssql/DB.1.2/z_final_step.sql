/* 
$Revision: 1.1 $
$Date: 2008/01/02 18:55:52 $
$Author: franciscom $
$Name:  $
*/
INSERT INTO db_version (version,upgrade_ts,notes) VALUES ('DB 1.2',GETDATE(),'first version with API feature');